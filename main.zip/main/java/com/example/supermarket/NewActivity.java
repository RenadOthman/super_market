package com.example.supermarket;
import static java.lang.System.exit;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;



import java.util.ArrayList;
import java.util.List;

public class NewActivity extends AppCompatActivity {

        RecyclerView discountRecyclerView, categoryRecyclerView, recentlyViewedRecycler;
        DiscountedProductAdapter discountedProductAdapter;
        List<DiscountedProducts> discountedProductsList;

        CategoryAdapter categoryAdapter;
        List<Category> categoryList;

        RecentlyViewedAdapter recentlyViewedAdapter;
        List<RecentlyViewed> recentlyViewedList;

        TextView allCategory;
        TextView llCategory;
ImageButton imageButto;
        FrameLayout nav;

        @Override
        protected void onCreate( Bundle savedInstanceState ) {
            super.onCreate ( savedInstanceState );
            setContentView ( R.layout.activity_main );


            discountRecyclerView = findViewById ( R.id.discountedRecycler );
            categoryRecyclerView = findViewById ( R.id.categoryRecycler );

            recentlyViewedRecycler = findViewById ( R.id.recently_item );
            imageButto=findViewById ( R.id.imageButto );



            imageButto.setOnClickListener ( new View.OnClickListener () {
                @Override
                public void onClick( View view ) {
                    Intent i = new Intent ( NewActivity.this , Payment_page.class );
                    startActivity ( i );
                }
            } );

            // adding data to model
            discountedProductsList = new ArrayList<> ();
            discountedProductsList.add ( new DiscountedProducts ( 1 , R.drawable.discountberry ) );
            discountedProductsList.add ( new DiscountedProducts ( 2 , R.drawable.discountbrocoli ) );
            discountedProductsList.add ( new DiscountedProducts ( 3 , R.drawable.discountmeat ) );
            discountedProductsList.add ( new DiscountedProducts ( 4 , R.drawable.discountberry ) );
            discountedProductsList.add ( new DiscountedProducts ( 5 , R.drawable.discountbrocoli ) );
            discountedProductsList.add ( new DiscountedProducts ( 6 , R.drawable.discountmeat ) );

            // adding data to model
            categoryList = new ArrayList<> ();
            categoryList.add ( new Category ( 1 , R.drawable.ic_home_fruits ) );
            categoryList.add ( new Category ( 2 , R.drawable.hh) );
            categoryList.add ( new Category ( 3 , R.drawable.ic_desert ) );



            // adding data to model
            recentlyViewedList = new ArrayList<> ();
            recentlyViewedList.add ( new RecentlyViewed ( "grapefruit" , "grapefruit has high water content and also provides some fiber." , "SAR 80" , "1" , "KG" , R.drawable.f1 , R.drawable.f1 ) );
            recentlyViewedList.add ( new RecentlyViewed ( "Watermelon" , "Watermelon are spherical or pear-shaped fruits that can be as long as 20 inches." , "SAR 85" , "1" , "KG" , R.drawable.f2 , R.drawable.f2 ) );
            recentlyViewedList.add ( new RecentlyViewed ( "apple" , "The apple is a highly nutritious fruit, loaded with vitamin C." , "SAR 30" , "1" , "KG" , R.drawable.f3 , R.drawable.f3 ) );
            recentlyViewedList.add ( new RecentlyViewed ( "Grape" , "Full of nutrients like vitamin C, vitamin K, vitamin E, folate, and potassium." , "SAR 30" , "1" , "KG" , R.drawable.f4 , R.drawable.f4 ) );

            recentlyViewedList.add ( new RecentlyViewed ( "apple" , "apple has high water content and also provides some fiber." , "SAR 80" , "1" , "KG" , R.drawable.f5 , R.drawable.f5 ) );
            recentlyViewedList.add ( new RecentlyViewed ( "peach" , "peach are spherical or pear-shaped fruits that can be as long as 20 inches." , "SAR 85" , "1" , "KG" , R.drawable.f6 , R.drawable.f6 ) );
            recentlyViewedList.add ( new RecentlyViewed ( "blueberry" , "The blueberry is a highly nutritious fruit, loaded with vitamin C." , "SAR 30" , "1" , "KG" , R.drawable.f7 , R.drawable.f7 ) );
            recentlyViewedList.add ( new RecentlyViewed ( "Red Mulberry" , "Full of nutrients like vitamin C, vitamin K, vitamin E, folate, and potassium." , "SAR 30" , "1" , "KG" , R.drawable.f8 , R.drawable.f8 ) );

            recentlyViewedList.add ( new RecentlyViewed ( "blueberry" , "blueberry has high water content and also provides some fiber." , "SAR 80" , "1" , "KG" , R.drawable.f9 , R.drawable.f9 ) );
            recentlyViewedList.add ( new RecentlyViewed ( "orange" , "orange are spherical or pear-shaped fruits that can be as long as 20 inches." , "SAR 85" , "1" , "KG" , R.drawable.f10 , R.drawable.f10 ) );
            recentlyViewedList.add ( new RecentlyViewed ( "Blackberry" , "The Blackberry is a highly nutritious fruit, loaded with vitamin C." , "SAR 30" , "1" , "KG" , R.drawable.f11 , R.drawable.f11 ) );
            recentlyViewedList.add ( new RecentlyViewed ( "grapes" , "Full of nutrients like vitamin C, vitamin K, vitamin E, folate, and potassium." , "SAR 30" , "1" , "KG" , R.drawable.f12 , R.drawable.f12 ) );

            recentlyViewedList.add ( new RecentlyViewed ( "avocado" , "avocado has high water content and also provides some fiber." , "SAR 80" , "1" , "KG" , R.drawable.f13 , R.drawable.f13 ) );
            recentlyViewedList.add ( new RecentlyViewed ( "samoli" , "French baguette." , "SAR 85" , "1" , "piece" , R.drawable.br1 , R.drawable.br1 ) );
            recentlyViewedList.add ( new RecentlyViewed ( "Smit" , "Turkish simit bread" , "SAR 30" , "1" , "piece" , R.drawable.br2 , R.drawable.br2 ) );
            recentlyViewedList.add ( new RecentlyViewed ( "bread" , "small bread." , "SAR 30" , "1" , "piece" , R.drawable.br3 , R.drawable.br3 ) );

            recentlyViewedList.add ( new RecentlyViewed ( "bread" , "bread." , "SAR 80" , "1" , "piece" , R.drawable.br4 , R.drawable.br4 ) );
            recentlyViewedList.add ( new RecentlyViewed ( "Chocolate cake" , "A piece of cake covered with delicious chocolate." , "SAR 85" , "1" , "piece" , R.drawable.k1 , R.drawable.k1 ) );
            recentlyViewedList.add ( new RecentlyViewed ( "Vanilla cake" , "TA piece of cake covered with delicious Vanilla" , "SAR 30" , "1" , "piece" , R.drawable.k3 , R.drawable.k3 ) );
            recentlyViewedList.add ( new RecentlyViewed ( "red velvet" , "Cake tastes good and delicious." , "SAR 30" , "1" , "piece" , R.drawable.k2 , R.drawable.k2 ) );

            recentlyViewedList.add ( new RecentlyViewed ( "Red velvet cupcake" , "Red velvet cupcake is Cake tastes good and delicious." , "SAR 80" , "1" , "piece" , R.drawable.k4 , R.drawable.k4 ) );
            recentlyViewedList.add ( new RecentlyViewed ( "Chocolate cupcake" , "Chocolate cupcake is Cake tastes good and delicious" , "SAR 85" , "1" , "piece" , R.drawable.k5 , R.drawable.k5 ) );
            recentlyViewedList.add ( new RecentlyViewed ( "Tiramisu cake" ,"Tiramisu cake piece of cake covered with delicious" ,"SAR 30" ,"1" ,"piece" ,R.drawable.k6 ,R.drawable.k1 ) );

            setDiscountedRecycler ( discountedProductsList );
            setCategoryRecycler ( categoryList );
            setRecentlyViewedRecycler ( recentlyViewedList );

        }

        private void setDiscountedRecycler( List<DiscountedProducts> dataList ) {
            RecyclerView.LayoutManager layoutManager = new LinearLayoutManager ( this , LinearLayoutManager.HORIZONTAL , false );
            discountRecyclerView.setLayoutManager ( layoutManager );
            discountedProductAdapter = new DiscountedProductAdapter ( this , dataList );
            discountRecyclerView.setAdapter ( discountedProductAdapter );
        }


        private void setCategoryRecycler( List<Category> categoryDataList ) {
            RecyclerView.LayoutManager layoutManager = new LinearLayoutManager ( this , LinearLayoutManager.HORIZONTAL , false );
            categoryRecyclerView.setLayoutManager ( layoutManager );
            categoryAdapter = new CategoryAdapter ( this , categoryDataList );
            categoryRecyclerView.setAdapter ( categoryAdapter );
        }

        private void setRecentlyViewedRecycler( List<RecentlyViewed> recentlyViewedDataList ) {
            RecyclerView.LayoutManager layoutManager = new LinearLayoutManager ( this , LinearLayoutManager.HORIZONTAL , false );
            recentlyViewedRecycler.setLayoutManager ( layoutManager );
            recentlyViewedAdapter = new RecentlyViewedAdapter ( this , recentlyViewedDataList );
            recentlyViewedRecycler.setAdapter ( recentlyViewedAdapter );
        }
        //Now again we need to create a adapter and model class for recently viewed items.
        // lets do it fast.
        @Override
        public void onPointerCaptureChanged(boolean hasCapture) {
            super.onPointerCaptureChanged(hasCapture);
        }

    public boolean onCreateOptionsMenu( Menu menu) {
        getMenuInflater().inflate(R.menu.menuu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected( MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.item1:
                Intent A = new Intent ( NewActivity.this , about.class );
                startActivity ( A );

            case R.id.item2:
                Intent iIntent = new Intent ( NewActivity.this , callus.class );
                startActivity ( iIntent );

            case R.id.item3:
             exit(0);

            default:
                return super.onOptionsItemSelected(item);

        }
    }
}



