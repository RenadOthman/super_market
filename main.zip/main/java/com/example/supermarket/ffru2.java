package com.example.supermarket;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ffru2 extends AppCompatActivity {
    RecentlyViewedAdapter recentlyViewedAdapter;
    ImageView llCategory;
    RecyclerView discountRecyclerView, categoryRecyclerView, recentlyViewedRecycler;
    List<RecentlyViewed> recentlyViewedList;
    CategoryAdapter categoryAdapter;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate( Bundle savedInstanceState ) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.fru );

        recentlyViewedRecycler = findViewById ( R.id.recently_item );


    // adding data to model
    recentlyViewedList = new ArrayList <>();
            recentlyViewedList.add ( new RecentlyViewed ( "grapefruit" , "grapefruit has high water content and also provides some fiber." , "SAR 80" , "1" , "KG" , R.drawable.f1 , R.drawable.f1 ) );
            recentlyViewedList.add ( new RecentlyViewed ( "Watermelon" , "Watermelon are spherical or pear-shaped fruits that can be as long as 20 inches." , "SAR 85" , "1" , "KG" , R.drawable.f2 , R.drawable.f2 ) );
            recentlyViewedList.add ( new RecentlyViewed ( "apple" , "The apple is a highly nutritious fruit, loaded with vitamin C." , "SAR 30" , "1" , "KG" , R.drawable.f3 , R.drawable.f3 ) );
            recentlyViewedList.add ( new RecentlyViewed ( "Grape" , "Full of nutrients like vitamin C, vitamin K, vitamin E, folate, and potassium." , "SAR 30" , "1" , "KG" , R.drawable.f4 , R.drawable.f4 ) );

    setRecentlyViewedRecycler ( recentlyViewedList );

}


    private void setCategoryRecycler( List<Category> categoryDataList ) {
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager ( this , LinearLayoutManager.HORIZONTAL , false );
        categoryRecyclerView.setLayoutManager ( layoutManager );
        categoryAdapter = new CategoryAdapter ( this , categoryDataList );
        categoryRecyclerView.setAdapter ( categoryAdapter );
    }

    private void setRecentlyViewedRecycler( List<RecentlyViewed> recentlyViewedDataList ) {
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager ( this , LinearLayoutManager.HORIZONTAL , false );
        recentlyViewedRecycler.setLayoutManager ( layoutManager );
        recentlyViewedAdapter = new RecentlyViewedAdapter ( this , recentlyViewedDataList );
        recentlyViewedRecycler.setAdapter ( recentlyViewedAdapter );
    }
    //Now again we need to create a adapter and model class for recently viewed items.
    // lets do it fast.
}