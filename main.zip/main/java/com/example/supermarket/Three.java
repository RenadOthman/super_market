package com.example.supermarket;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Three extends AppCompatActivity {


    TextView a,b;

Button startsho;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate( Bundle savedInstanceState ) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.thre );

        a = findViewById ( R.id.button2 );
        b = findViewById ( R.id.button3 );



        startsho = findViewById ( R.id.startsho );
        startsho.setOnClickListener ( new View.OnClickListener () {
            @Override
            public void onClick( View view ) {
                Intent i = new Intent ( Three.this , login.class );
                startActivity ( i );
            }
        } );
        a.setOnClickListener ( new View.OnClickListener () {
            @Override
            public void onClick( View view ) {
                Intent i = new Intent ( Three.this , NewActivity.class );
                startActivity ( i );
            }
        } );
        b.setOnClickListener ( new View.OnClickListener () {
            @Override
            public void onClick( View view ) {
                Intent i = new Intent ( Three.this , registration.class );
                startActivity ( i );
            }
        } );




    }}
