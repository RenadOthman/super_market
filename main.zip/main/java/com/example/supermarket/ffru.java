package com.example.supermarket;
/*
import static com.exampel.supermarket.R.drawable.b1;
import static com.exampel.supermarket.R.drawable.b2;
import static com.exampel.supermarket.R.drawable.b3;
import static com.exampel.supermarket.R.drawable.b4;
import static com.exampel.supermarket.R.drawable.card1;
import static com.exampel.supermarket.R.drawable.card2;
import static com.exampel.supermarket.R.drawable.card3;
import static com.exampel.supermarket.R.drawable.card4;
import static com.exampel.supermarket.R.drawable.discountberry;
import static com.exampel.supermarket.R.drawable.discountbrocoli;
import static com.exampel.supermarket.R.drawable.discountmeat;
import static com.exampel.supermarket.R.drawable.f1;
import static com.exampel.supermarket.R.drawable.f2;
import static com.exampel.supermarket.R.drawable.f3;
import static com.exampel.supermarket.R.drawable.f4;
import static com.exampel.supermarket.R.drawable.hh;
import static com.exampel.supermarket.R.drawable.ib;
import static com.exampel.supermarket.R.drawable.ic_desert;
import static com.exampel.supermarket.R.drawable.ic_home_fish;
import static com.exampel.supermarket.R.drawable.ic_home_fruits;
import static com.exampel.supermarket.R.drawable.ic_home_meats;
import static com.exampel.supermarket.R.drawable.ic_home_veggies;
import static com.exampel.supermarket.R.drawable.iconcake;
import static com.exampel.supermarket.R.drawable.yb;
*/
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
/*
import com.exampel.supermarket.adapter.CategoryAdapter;
import com.exampel.supermarket.adapter.DiscountedProductAdapter;
import com.exampel.supermarket.adapter.RecentlyViewedAdapter;
import com.exampel.supermarket.model.Category;
import com.exampel.supermarket.model.DiscountedProducts;
import com.exampel.supermarket.model.RecentlyViewed;
*/
import java.util.ArrayList;
import java.util.List;

public class ffru

        extends AppCompatActivity {

    List<Category> categoryList;

    RecentlyViewedAdapter recentlyViewedAdapter;
    List<RecentlyViewed> recentlyViewedList;

    TextView allCategory;
    TextView llCategory;

    FrameLayout nav;
    private RecyclerView categoryRecyclerView;
    private CategoryAdapter categoryAdapter;

    @Override
    protected void onCreate( Bundle savedInstanceState ) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_main );




        allCategory.setOnClickListener ( new View.OnClickListener () {
            @Override
            public void onClick( View view ) {
                Intent i = new Intent( ffru.this , AllCategory.class );
                startActivity ( i );
            }
        } );


        // adding data to model
        categoryList = new ArrayList<> ();
        categoryList.add ( new Category ( 1 , R.drawable.ic_home_fruits ) );
        categoryList.add ( new Category ( 2 , R.drawable.hh) );
        categoryList.add ( new Category ( 3 , R.drawable.ic_desert ) );



        setCategoryRecycler ( categoryList );

    }



    private void setCategoryRecycler( List<Category> categoryDataList ) {
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager ( this , LinearLayoutManager.HORIZONTAL , false );
        categoryRecyclerView.setLayoutManager ( layoutManager );
        categoryAdapter = new CategoryAdapter ( this , categoryDataList );
        categoryRecyclerView.setAdapter ( categoryAdapter );
    }

}



