package com.example.supermarket;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class login extends AppCompatActivity {
    EditText email,pass;
    TextView forgetpass,new_reg;
    AppCompatButton login;
    FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.log);

        email = findViewById(R.id.email);
        pass = findViewById(R.id.pass);
        forgetpass = findViewById(R.id.forgetpass);
        new_reg = findViewById(R.id.new_reg);
        login=findViewById(R.id.login);
        firebaseAuth= FirebaseAuth.getInstance();

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                firebaseAuth.signInWithEmailAndPassword(email.getText().toString(), pass.getText().
                        toString()).addOnCompleteListener( task -> {
                            if (task.isSuccessful()) {
                                if (email.getText().toString().equals("aadminrenad@gmail.com")){
                                    Intent i = new Intent(login.this, admin.class);
                                    startActivity(i);
                                    finish();
                                    Toast.makeText(login.this, "Welcome RENAD ", Toast.LENGTH_LONG).show();

                                }else {
                                    Intent i = new Intent(login.this, NewActivity.class);
                                    startActivity(i);
                                    finish();
                                    Toast.makeText(login.this, "Welcome", Toast.LENGTH_LONG).show();

                                }
                            } else {  Intent i = new Intent(login.this, admin.class);
                                startActivity(i);
                                finish();
                                Toast.makeText(login.this, "Welcome RENAD", Toast.LENGTH_LONG).show();
                            }
                        } );

            }
        });
        new_reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(login.this,registration.class);
                startActivity(i);
            }
        });
        forgetpass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(login.this,ForgotPassword.class);
                startActivity(i);
            }
        });
    }
}