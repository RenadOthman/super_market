package com.example.supermarket;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.FrameLayout;
import android.widget.TextView;

import android.os.Bundle;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

@SuppressWarnings("ALL")
public class MainActivity extends AppCompatActivity {

    RecyclerView discountRecyclerView, categoryRecyclerView, recentlyViewedRecycler;
    DiscountedProductAdapter discountedProductAdapter;
    List<DiscountedProducts> discountedProductsList;

    CategoryAdapter categoryAdapter;
    List<Category> categoryList;

    RecentlyViewedAdapter recentlyViewedAdapter;
    List<RecentlyViewed> recentlyViewedList;

    TextView allCategory;
    TextView llCategory;

    FrameLayout nav;
    Timer timer;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newactivit);


        timer=new Timer ();
        timer.schedule ( new TimerTask() {
            @Override
            public void run() {
                Intent intent = new Intent ( MainActivity.this , Three.class );
                startActivity ( intent );
                finish ();
            }
        } , 4000 );
    }
}