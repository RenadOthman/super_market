package com.example.supermarket;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.IOException;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class registration extends AppCompatActivity {
    EditText phon,pass,email,name,date,city;
    TextView log;
    Button new_log;
    FirebaseAuth firebaseAuth;
    FirebaseUser firebaseUser;
    DatabaseReference databaseReference;
    ImageView image_upload;
    private Uri filePath;

    // request code
    private final int PICK_IMAGE_REQUEST = 22;
    FirebaseStorage storage;
    StorageReference storageReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.reg );
        phon = findViewById ( R.id.phon );
        pass = findViewById ( R.id.password );
        name = findViewById ( R.id.name );
        email = findViewById ( R.id.emails );
        city = findViewById ( R.id.city );

        storage = FirebaseStorage.getInstance ();
        storageReference = storage.getReference ();

        new_log = findViewById ( R.id.register );
        firebaseAuth = FirebaseAuth.getInstance ();
        databaseReference = FirebaseDatabase.getInstance ().getReference ().child ( "users" );
        new_log.setOnClickListener ( new View.OnClickListener () {
            @Override
            public void onClick( View view ) {
                firebaseAuth.createUserWithEmailAndPassword ( email.getText ().toString () ,pass.getText ().toString () ).addOnCompleteListener ( new OnCompleteListener < AuthResult > () {
                    @Override
                    public void onComplete( @NonNull Task < AuthResult > task ) {

                        if (task.isSuccessful ()) {
                            firebaseUser = task.getResult ().getUser ();
                            DatabaseReference newUser = databaseReference.child ( firebaseUser.getUid () );
                            newUser.child ( "email" ).setValue ( email.getText ().toString () );
                            newUser.child ( "password" ).setValue ( pass.getText ().toString () );
                            newUser.child ( "phon" ).setValue ( phon.getText ().toString () );
                            newUser.child ( "name" ).setValue ( name.getText ().toString () );
                            newUser.child ( "city" ).setValue ( city.getText ().toString () );

                            Toast.makeText ( registration.this ," register done" ,Toast.LENGTH_LONG ).show ();
                            Intent toSigin = new Intent ( registration.this ,NewActivity.class );
                            startActivity ( toSigin );
                            finish ();
                        } else {
                            Toast.makeText ( registration.this ,"Error" ,Toast.LENGTH_LONG ).show ();

                        }
                    }
                } );

            }
        } );
    }
        boolean isEmailValid(CharSequence email) {
            return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
        }



    }
