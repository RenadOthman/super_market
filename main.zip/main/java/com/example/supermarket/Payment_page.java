package com.example.supermarket;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class Payment_page extends AppCompatActivity {


    @Override
    protected void onCreate( Bundle savedInstanceState ) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.payment );} public void onClick(View view) {
            Intent i = new Intent( Payment_page.this,NewActivity.class);
            startActivity(i);
        }}